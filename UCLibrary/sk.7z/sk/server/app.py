from flask import Flask, request, jsonify
from flask_cors import CORS
from datetime import datetime
import mysql.connector


app = Flask(__name__)
CORS(app, origins="*")

db_connection = mysql.connector.connect(
    host = '127.0.0.1',
    user = 'root',
    password = 'Wolves081314',
    database= 'Store_data'
)
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
    response.headers.add('Access-Control-Allow-Methods', 'GET, POST, DELETE, PUT')
    return response

@app.route('/item/<string:item_id>', methods=['PUT', 'GET', 'DELETE'])
def get_item(item_id):
    cursor = db_connection.cursor()
    if request.method == 'GET':
        try:
            query = 'SELECT * FROM item WHERE item_id = %s'
            cursor.execute(query, (item_id,))
            item = cursor.fetchone()

            if item:
                dict = {
                    'item_id': item[0],
                    'item_name': item[1],
                    'item_type': item[2],
                    'item_brand': item[3],
                    'item_cur_qty': item[4]
                }
                return jsonify(dict), 200
            else:
                return jsonify({'status': 'NOT_FOUND'}), 404
        except Exception as e:
            return jsonify({'status': str(e)}), 400
        finally:
            cursor.close()
    elif request.method == "PUT":
        try:
            data = request.get_json()
            item_id = data.get('item_id')
            item_name = data.get('item_name')
            item_type = data.get('item_type')
            item_brand = data.get('item_brand')

            query = 'UPDATE item SET item_name = %s, item_type = %s, item_brand = %s WHERE item_id = %s'
            cursor.execute(query, (item_name, item_type, item_brand, item_id))
            db_connection.commit()

            return jsonify({ 'status': 'OK' }), 200
        except Exception as e:
            return jsonify({'status': str(e)}), 400
        finally:
            cursor.close()
    elif request.method == "DELETE":
        try:
            query = 'DELETE FROM item WHERE item_id = %s'
            cursor.execute(query, (item_id,))
            db_connection.commit()
            return jsonify({'status': 'OK'}), 200
        except Exception as e:
            return jsonify({'status': str(e)}), 400
        finally:
            cursor.close()


@app.route('/trans_in_out/<string:trans_id>', methods=['PUT', 'GET'])
def get_trans(trans_id):
    cursor = db_connection.cursor()
    if request.method == 'GET':
        try:
            query = 'SELECT * FROM trans_in_out WHERE trans_item_id = %s'
            cursor.execute(query, (trans_id,))
            trans_in_out = cursor.fetchone()

            if trans_in_out\
                    :
                dict = {
                    'trans_id': trans_in_out[0],
                    'trans_date': trans_in_out[1],
                    'trans_item_id': trans_in_out[2],
                    'trans_type': trans_in_out[3],
                    'trans_qty': trans_in_out[4]
                }

                return jsonify(dict2), 200
            else:
                return jsonify({'status': 'NOT_FOUND'}), 404
        except Exception as e:
            return jsonify({'status': str(e)}), 400
        finally:
            cursor.close()
    elif request.method == "PUT":
            cursor.close()

@app.route('/trans_in_out', methods=['POST', 'GET'])
def add_trans():
        if request.method == 'POST':
            data = request.get_json()
            cursor = db_connection.cursor()
            try:
                trans_item_id = data.get('trans_item_id')
                trans_type = data.get('trans_type')
                trans_qty = data.get('trans_qty')

                query = 'INSERT INTO trans_in_out (trans_item_id, trans_type, trans_qty) VALUES (%s, %s, %s)'
                cursor.execute(query, (trans_item_id, trans_type, trans_qty))
                db_connection.commit()

                return jsonify({'status': 'OK'}), 201
            except Exception as e:
                db_connection.rollback()
                return jsonify({'status': str(e)}), 400
            finally:
                cursor.close()
        elif request.method == 'GET':
            cursor = db_connection.cursor()
            try:
                query = 'SELECT trans_item_id, DATE_FORMAT(trans_date, "%Y-%m-%d") AS trans_date, ' \
                        'CASE WHEN trans_type = "+N" THEN "Input" ' \
                        'WHEN trans_type = "+O" THEN "Opname (Tambah)" ' \
                        'WHEN trans_type = "-O" THEN "Opname (Kurang)" ' \
                        'WHEN trans_type = "+R" THEN "Restok" ' \
                        'WHEN trans_type = "-S" THEN "Penjualan" ' \
                        'ELSE trans_type ' \
                        'END AS transformed_trans_type, trans_qty ' \
                        'FROM trans_in_out ' \
                        'ORDER BY trans_item_id, trans_date'
                cursor.execute(query)
                results = cursor.fetchall()

                list = []

                for trans_in_out in results:
                    dict = {
                        'trans_item_id': trans_in_out[0],
                        'trans_date': trans_in_out[1],
                        'transformed_trans_type': trans_in_out[2],
                        'trans_qty': trans_in_out[3]
                    }
                    list.append(dict)

                return jsonify(list), 200
            except Exception as e:
                return jsonify({'status': str(e)}), 400
            finally:
                cursor.close()
        return 'EMPTY'

@app.route('/trans', methods=['POST', 'GET'])
def transaction():
    if request.method == 'POST':
        data = request.get_json()
        cursor = db_connection.cursor()
        try:
            trans_item_id = data.get('trans_item_id')
            trans_type = data.get('trans_type')
            trans_qty = data.get('trans_qty')

            query = 'INSERT INTO trans_in_out (trans_item_id, trans_type, trans_qty) VALUES ( %s, %s, %s)'
            cursor.execute(query, (trans_item_id, trans_type, trans_qty))
            db_connection.commit()

            return jsonify({'status': 'OK'}), 201
        except Exception as e:
            db_connection.rollback()
            return jsonify({'status': str(e)}), 400
        finally:
            cursor.close()

    elif request.method == 'GET':
        cursor = db_connection.cursor()
        try:
            query = 'SELECT trans_date, trans_type, trans_qty FROM trans_in_out WHERE trans_item_id = %s'
            cursor.execute(query)
            results = cursor.fetchall()

            list = []

            for trans_in_out in results:
                dict2 = {
                    'trans_date' : trans_date [0],
                    'trans_item_id': trans_in_out[1],
                    'trans_type': trans_in_out[2],
                    'trans_qty': trans_in_out[3]
                }
                list.append(dict2)

            return jsonify(list), 200
        except Exception as e:
            return jsonify({'status': str(e)}), 400
        finally:
            cursor.close()
    return 'EMPTY'

@app.route('/item', methods=['POST', 'GET'])
def add_item():
    if request.method == 'POST':
        data = request.get_json()
        cursor = db_connection.cursor()

        try:
            item_name = data.get('item_name')
            item_type = data.get('item_type')
            item_brand = data.get('item_brand')
            item_cur_qty = data.get('item_cur_qty')

            query = 'INSERT INTO item (item_name, item_type, item_brand, item_cur_qty) VALUES (%s, %s, %s, %s)'
            cursor.execute(query, (item_name, item_type, item_brand, item_cur_qty))
            db_connection.commit()

            return jsonify({ 'status': 'OK' }), 201
        except Exception as e:
            db_connection.rollback()
            return jsonify({ 'status': str(e) }), 400
        finally:
            cursor.close()
    elif request.method == 'GET':
        cursor = db_connection.cursor()
        try:
            query = 'SELECT * FROM item'
            cursor.execute(query)
            results = cursor.fetchall()

            list = []

            for item in results:
                dict = {
                    'item_id': item[0],
                    'item_name': item[1],
                    'item_type': item[2],
                    'item_brand': item[3],
                    'item_cur_qty': item[4]
                }
                list.append(dict)

            return jsonify(list), 200
        except Exception as e:
            return jsonify({'status': str(e)}), 400
        finally:
            cursor.close()
    return 'EMPTY'

@app.route('/opname', methods=['POST', 'GET'])
def opname():
    if request.method == 'POST':
        data = request.get_json()
        cursor = db_connection.cursor()
        try:
            opname_item_id = data.get('item_id')
            opname_db_qty = data.get('item_cur_qty')
            opname_store_qty = data.get('opname_store_qty')
            opname_reason = data.get('opname_reason')

            query = 'INSERT INTO stock_opname (opname_item_id, opname_db_qty, opname_store_qty, opname_reason) VALUES ( %s, %s, %s, %s )'
            cursor.execute(query, (opname_item_id, opname_db_qty, opname_store_qty, opname_reason))
            db_connection.commit()

            return jsonify({'status': 'OK'}), 201
        except Exception as e:
            db_connection.rollback()
            return jsonify({'status': str(e)}), 400
        finally:
            cursor.close()

    elif request.method == 'GET':
        cursor = db_connection.cursor()
        try:
            query = 'SELECT * FROM stock_opname'
            cursor.execute(query)
            results = cursor.fetchall()

            list = []

            for stock_opname in results:
                dict2 = {
                    'opname_date' : stock_opname[0],
                    'opname_item_id': stock_opname[1],
                    'opname_db_qty': stock_opname[2],
                    'opname_store_qty': stock_opname[3],
                    'opname_reason': stock_opname[4]
                }
                list.append(dict2)

            return jsonify(list), 200
        except Exception as e:
            return jsonify({'status': str(e)}), 400
        finally:
            cursor.close()
    return 'EMPTY'

@app.route('/opnametab', methods=['GET'])
def opnametab():
    if request.method == 'GET':
        cursor = db_connection.cursor()
        try:
            query = 'SELECT DATE_FORMAT(opname_date, "%Y-%m-%d") AS opname_date, opname_item_id, opname_db_qty, opname_store_qty, opname_reason FROM stock_opname Order by 1 desc'
            cursor.execute(query)
            results = cursor.fetchall()

            list = []

            for stock_opname in results:
                dict2 = {
                    'opname_date': stock_opname[0],
                    'opname_item_id': stock_opname[1],
                    'opname_db_qty': stock_opname[2],
                    'opname_store_qty': stock_opname[3],
                    'opname_reason': stock_opname[4]
                }
                list.append(dict2)

            return jsonify(list), 200
        except Exception as e:
            return jsonify({'status': str(e)}), 400
        finally:
            cursor.close()
    return 'EMPTY'

@app.route('/sales', methods=['GET'])
def sales():
    if request.method == 'GET':
        data = request.get_json()
        cursor = db_connection.cursor()
        try:
            trans_item_id = data.get('item_id')
            query = 'SELECT DATE_FORMAT(trans_date, "%Y-%m-%d") AS trans_date, trans_type, trans_qty FROM trans_in_out WHERE trans_item_id = %s'
            cursor.execute(query, (trans_item_id,))
            trans_in_out = cursor.fetchone()

            if trans_in_out\
                    :
                dict = {
                    'trans_id': trans_in_out[0],
                    'trans_date': trans_in_out[1],
                    'trans_item_id': trans_in_out[2],
                    'trans_type': trans_in_out[3],
                    'trans_qty': trans_in_out[4]
                }

                return jsonify(dict2), 200
            else:
                return jsonify({'status': 'NOT_FOUND'}), 404
        except Exception as e:
            return jsonify({'status': str(e)}), 400
        finally:
            cursor.close()
    elif request.method == "PUT":
            cursor.close()

@app.route('/trans_report/<trans_item_id>', methods=['GET'])
def trans_report(trans_item_id):
    if request.method == 'GET':
        cursor = db_connection.cursor()
        try:
            query = 'SELECT trans_item_id, DATE_FORMAT(trans_date, "%Y-%m-%d") AS trans_date, ' \
                    'CASE WHEN trans_type = "+N" THEN "Input" ' \
                    'WHEN trans_type = "+O" THEN "Opname (Tambah)" ' \
                    'WHEN trans_type = "-O" THEN "Opname (Kurang)" ' \
                    'WHEN trans_type = "+R" THEN "Restok" ' \
                    'WHEN trans_type = "-S" THEN "Penjualan" ' \
                    'ELSE trans_type ' \
                    'END AS transformed_trans_type,' \
                    'CASE WHEN trans_type = "+N" THEN "+" ' \
                    'WHEN trans_type = "+O" THEN "+" ' \
                    'WHEN trans_type = "-O" THEN "-" ' \
                    'WHEN trans_type = "+R" THEN "+" ' \
                    'WHEN trans_type = "-S" THEN "-" ' \
                    'ELSE trans_type ' \
                    'END AS sign_trans_type,' \
                    'trans_qty, trans_total ' \
                    'FROM trans_in_out WHERE trans_item_id = %s'
            cursor.execute(query, (trans_item_id,))
            results = cursor.fetchall()

            result_list = []

            for trans_in_out in results:
                dict2 = {
                    'trans_item_id': trans_in_out[0],
                    'trans_date': trans_in_out[1],
                    'transformed_trans_type': trans_in_out[2],
                    'sign_trans_type': trans_in_out[3],
                    'trans_qty': trans_in_out[4],
                    'trans_total': trans_in_out[5]
                }
                result_list.append(dict2)

            return jsonify(result_list), 200
        except Exception as e:
            return jsonify({'status': str(e)}), 400
        finally:
            cursor.close()
    return 'EMPTY'

@app.route('/Ranking', methods=['GET'])
def Get_Ranking():
    GroupBy = request.args.get('GroupBy')  # Use request.args to get query parameters
    trans_date = request.args.get('trans_date')
    SortBy = request.args.get('SortBy')
    if SortBy == 'Highest':
        if GroupBy == 'Item_ID':
            try:
                cursor = db_connection.cursor()
                query = 'SELECT trans_item_id, SUM(trans_qty) AS total_sales ' \
                        'FROM trans_in_out ' \
                        'WHERE trans_date > %s AND trans_type = "-S" ' \
                        'GROUP BY trans_item_id; '
                cursor.execute(query, (trans_date,))
                trans_in_out = cursor.fetchall()

                if trans_in_out:
                    result = []  # Create a list to store results
                    for row in trans_in_out:
                        dict_item = {
                            'trans_item_id': row[0],
                            'total_sales': row[1],
                        }
                        result.append(dict_item)

                    return jsonify(result), 200
                else:
                    return jsonify({'status': 'NOT_FOUND'}), 404
            except Exception as e:
                return jsonify({'status': str(e)}), 400
            finally:
                cursor.close()

        elif GroupBy == 'Brand':
            try:
                cursor = db_connection.cursor()
                query = '''
                    SELECT item_brand, SUM(trans_qty) AS total_sales
                    FROM trans_in_out, item
                    WHERE trans_date > %s AND trans_type = '-S' AND item_id = trans_item_id
                    GROUP BY item_brand;
                '''
                cursor.execute(query, (trans_date,))
                trans_in_out = cursor.fetchall()

                if trans_in_out:
                    result = []
                    for row in trans_in_out:
                        dict_item = {
                            'item_brand': row[0],
                            'total_sales': row[1],
                        }
                        result.append(dict_item)

                    return jsonify(result), 200
                else:
                    return jsonify({'status': 'NOT_FOUND'}), 404
            except Exception as e:
                return jsonify({'status': str(e)}), 400
            finally:
                cursor.close()

        elif GroupBy == 'Type':
            try:
                cursor = db_connection.cursor()
                query = '''
                    SELECT item_type, SUM(trans_qty) AS total_sales
                    FROM trans_in_out, item
                    WHERE trans_date > %s AND trans_type = '-S' AND trans_item_id = item_id
                    GROUP BY item_type;
                '''
                cursor.execute(query, (trans_date,))
                trans_in_out = cursor.fetchall()

                if trans_in_out:
                    result = []
                    for row in trans_in_out:
                        dict_item = {
                            'item_type': row[0],
                            'total_sales': row[1],
                        }
                        result.append(dict_item)

                    return jsonify(result), 200
                else:
                    return jsonify({'status': 'NOT_FOUND'}), 404
            except Exception as e:
                return jsonify({'status': str(e)}), 400
            finally:
                cursor.close()

    elif SortBy == 'Lowest':
        if GroupBy == 'Item_ID':
            try:
                cursor = db_connection.cursor()
                query = 'SELECT item_id, item_name, item_cur_qty ' \
                        'FROM item ' \
                        'WHERE item_id NOT IN (' \
                        'SELECT trans_item_id ' \
                        'FROM trans_in_out ' \
                        'WHERE trans_type = "-S") ' \
                        'ORDER BY created_at ASC;'

                cursor.execute(query)
                item = cursor.fetchall()

                if item:
                    result = []  # Create a list to store results
                    for row in item:
                        dict_item = {
                            'item_id': row[0],
                            'item_name': row[1],
                            'item_cur_qty': row[2]
                        }
                        result.append(dict_item)

                    return jsonify(result), 200
                else:
                    return jsonify({'status': 'NOT_FOUND'}), 404
            except Exception as e:
                return jsonify({'status': str(e)}), 400
            finally:
                cursor.close()

        elif GroupBy == 'Brand':
            try:
                cursor = db_connection.cursor()
                query = '''
                    SELECT item_brand, SUM(trans_qty) AS total_sales
                    FROM trans_in_out, item
                    WHERE trans_date > %s AND trans_type = '-S' AND item_id = trans_item_id
                    GROUP BY item_brand;
                '''
                cursor.execute(query, (trans_date,))
                trans_in_out = cursor.fetchall()

                if trans_in_out:
                    result = []
                    for row in trans_in_out:
                        dict_item = {
                            'item_brand': row[0],
                            'total_sales': row[1],
                        }
                        result.append(dict_item)

                    return jsonify(result), 200
                else:
                    return jsonify({'status': 'NOT_FOUND'}), 404
            except Exception as e:
                return jsonify({'status': str(e)}), 400
            finally:
                cursor.close()

        elif GroupBy == 'Type':
            try:
                cursor = db_connection.cursor()
                query = '''
                    SELECT item_type, SUM(trans_qty) AS total_sales
                    FROM trans_in_out, item
                    WHERE trans_date > %s AND trans_type = '-S' AND trans_item_id = item_id
                    GROUP BY item_type;
                '''
                cursor.execute(query, (trans_date,))
                trans_in_out = cursor.fetchall()

                if trans_in_out:
                    result = []
                    for row in trans_in_out:
                        dict_item = {
                            'item_type': row[0],
                            'total_sales': row[1],
                        }
                        result.append(dict_item)

                    return jsonify(result), 200
                else:
                    return jsonify({'status': 'NOT_FOUND'}), 404
            except Exception as e:
                return jsonify({'status': str(e)}), 400
            finally:
                cursor.close()

    # Handle the case where none of the conditions are met
    return jsonify({'status': 'INVALID_REQUEST'}), 400


if __name__ == '__main__':
    app.run(debug=True)

