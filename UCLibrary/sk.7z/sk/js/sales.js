class Sales {
  constructor(trans_item_id) {
    this.trans_item_id = trans_item_id;
  }

  async get() {
    const trans_item_id = this.trans_item_id;

    try {
      const response = await fetch(`http://localhost:5000/trans_report/${trans_item_id}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        return response.json();
      }

      // Handle errors here if needed
      return null;
    } catch (error) {
      console.error(error);
      return null;
    }
  }
}