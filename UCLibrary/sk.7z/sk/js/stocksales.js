// Extract trans_item_id from localStorage
const trans_item_id = localStorage.getItem('trans_item_id');

if (trans_item_id) {
  // Make a request to http://localhost:5000/trans_report/${trans_item_id}
  fetch(`http://localhost:5000/trans_report/${trans_item_id}`)
    .then(response => {
      if (response.status === 200) {
        return response.json();
      } else {
        throw new Error("Failed to fetch data");
      }
    })
    .then(uctable => {
      // Populate the tables with the retrieved data
      populateTables(uctable, 'uc-table-stock');
    })
    .catch(error => {
      console.error(error);
    });
} else {
  // Handle the case where trans_item_id is not available in localStorage
  console.log("trans_item_id is missing from localStorage");
}

function populateTables(uctable, tableId) {
  if (uctable) {
    const ucTable = document.querySelector(`#${tableId}`);
    let innerHTML = "";

    for (const item of uctable) {
      const row = `
        <div class="uc-table-row">
          <span class="uc-table-row-data uc-table-row-data-titemid">${item.trans_item_id}</span>
          <span class="uc-table-row-data uc-table-row-data-tdate">${item.trans_date}</span>
          <span class="uc-table-row-data uc-table-row-data-ttype">${item.transformed_trans_type}</span>
          <span class="uc-table-row-data uc-table-row-data-ttype2">${item.sign_trans_type}</span>
          <span class="uc-table-row-data uc-table-row-data-tqty">${item.trans_qty || 0}</span>
          <span class="uc-table-row-data uc-table-row-data-total">${item.trans_total || 0}</span>
        </div>
      `;
      innerHTML += row;
    }

    ucTable.innerHTML = innerHTML;
  }
}
