class trans_in_out {
  constructor(trans_item_id, trans_type, trans_qty) {
    this.trans_item_id = trans_item_id
    this.trans_type = trans_type
    this.trans_qty = trans_qty
  }

  async save() {
    // SAVE TO DB
    return await fetch("http://localhost:5000/trans", {
        method: "POST",
        body: JSON.stringify(this),
        headers: {
            "Content-Type": "application/json"
        }

    })
  }
        }