const button = document.querySelector("button.uc-form-button-submit")
let edit_item = null

button.addEventListener("click", (e) => {
    e.preventDefault()
    const item_name = document.querySelector("#item_name").value
    const item_type = document.querySelector("#item_type").value
    const item_brand = document.querySelector("#item_brand").value
    const item_cur_qty = parseInt(document.querySelector("#item_cur_qty").value)

    if (
        item_name &&
        item_type &&
        item_brand &&
        item_cur_qty >= 0
    ) {
        const item = new Item(item_name, item_type, item_brand, item_cur_qty)
        if (edit_item) {
            item.setId(edit_item.item_id)
            item.update(item_name, item_type, item_brand)
        } else {
            item.save()
        }
    }
        setTimeout(() => {
            window.location.href = "Database-Stok-search.html";
        }, 1000);
})

window.onload = async function() {
    const edit_id = localStorage.getItem('item-edit-id')
    if (edit_id) {
        edit_item = await loadItem(edit_id)

        if (edit_item) {
            document.querySelector("#SKU").value = edit_item.SKU || ""
            document.querySelector("#item_name").value = edit_item.item_name || ""
            document.querySelector("#item_type").value = edit_item.item_type || ""
            document.querySelector("#item_brand").value = edit_item.item_brand || ""
            document.querySelector("#item_cur_qty").value = edit_item.item_cur_qty || "0"
            document.querySelector("#item_cur_qty").setAttribute("readonly", true)
        }

    }
    localStorage.removeItem('item-edit-id')
}



async function loadItem(id) {
    try {
      const response = await fetch(`http://localhost:5000/item/${id}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json"
        }
      })
      if (response.status === 200) {
        return await response.json()
      }
      return null
    } catch {
      return null
    }
  }