const button = document.querySelector("button.uc-form-button-submit")
let edit_item = null



button.addEventListener("click", async (e) => {
  e.preventDefault()

  const trans_item_id = document.querySelector("#item_id").value;

  localStorage.setItem('trans_item_id', trans_item_id);

  window.location.href = "SalesReportTab.html";
});

window.onload = async function() {
  const edit_id = localStorage.getItem('item-edit-id');
  if (edit_id) {
    edit_item = await loadItem(edit_id);

    if (edit_item) {
      document.querySelector("#item_id").value = edit_item.item_id || "";
    }
  }
  localStorage.removeItem('item-edit-id');
};

async function loadItem(id) {
  try {
    const response = await fetch(`http://localhost:5000/item/${id}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json"
      }
    });
    if (response.status === 200) {
      return await response.json();
    }
    return null;
  } catch {
    return null;
  }
}

