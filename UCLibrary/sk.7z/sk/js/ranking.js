class Ranking {
constructor(GroupBy, trans_date){
    this.GroupBy = GroupBy;
    this.trans_date = trans_date;
    this.SortBy = SortBy;
  }

async get() {
  const trans_date = this.trans_date;
  const GroupBy = this.GroupBy;
  const SortBy = this.SortBy;

  try {
    const response = await fetch(`http://localhost:5000/Ranking?GroupBy=${GroupBy}&trans_date=${trans_date}&SortBy=${SortBy}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },

    });

    if (response.ok) {
      return response.json();
      console.log(trans_date,GroupBy, SortBy)
    }

    // Handle errors here if needed
    return null;
  } catch (error) {
    console.error(trans_date,GroupBy, SortBy);
    return null;
  }
} }