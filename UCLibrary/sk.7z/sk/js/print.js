document.getElementById("printButton").addEventListener("click", function () {
    window.print();
});

const printTitle = document.querySelector('.print-title');
const currentDate = new Date();

window.addEventListener('beforeprint', function () {
    const formattedDate = currentDate.toLocaleDateString() + ' ' + currentDate.toLocaleTimeString();
    const printTitle = document.querySelector('.print-title');
    const printTitleRiwayat = document.querySelector('.print-title-riwayat');

    if (printTitle) {
        printTitle.textContent = `Stok di dalam Database direkam pada tanggal: ${formattedDate}`;
    }

    if (printTitleRiwayat) {
        printTitleRiwayat.textContent = `Transaksi di dalam Database direkam pada tanggal: ${formattedDate}`;
    }
});
