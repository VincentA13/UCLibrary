class trans_in_out {
  constructor(trans_id, trans_date, trans_item_id, trans_qty) {
    this.trans_id = trans_id
    this.trans_date = trans_date
    this.trans_item_id = trans_item_id
    this.trans_type = trans_type
    this.trans_qty = trans_qty
  }

  setId(id) {
    this.trans_id = id
  }
  async isUnique(id) {
    // CHECK IF ITEM's ID IS UNIQUE
    return true
  }
  async save() {
    if (trans_item_id) this.trans_item_id = trans_item_id
    if (trans_type) this.trans_type = trans_type
    if (trans_qty) this.trans_qty = trans_qty
    // SAVE TO DB
    return await fetch("http://localhost:5000/trans_in_out", {
        method: "POST",
        body: JSON.stringify(this),
        headers: {
            "Content-Type": "application/json"
        }
    })
  }
  async update(trans_date, trans_item_id, trans_type, trans_qty) {
    if (trans_date) this.trans_date = trans_date
    if (trans_item_id) this.trans_item_id = trans_item_id
    if (trans_type) this.trans_type = trans_type
    if (trans_qty) this.trans_qty = trans_qty
    // UPDATE TO DB
    return await fetch(`http://localhost:5000/trans_in_out/${this.trans_id}`, {
        method: "PUT",
        body: JSON.stringify(this),
        headers: {
            "Content-Type": "application/json"
        }
    })
  }
}


