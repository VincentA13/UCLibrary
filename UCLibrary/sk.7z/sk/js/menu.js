class Opname {
  constructor(opname_item_id, opname_db_qty, opname_store_qty, opname_reason) {
    this.item_id = opname_item_id;
    this.item_cur_qty = opname_db_qty;
    this.opname_store_qty = opname_store_qty;
    this.opname_reason = opname_reason;
  }

  async save() {
    // SAVE TO DB
    return await fetch("http://localhost:5000/opname", {
        method: "POST",
        body: JSON.stringify(this),
        headers: {
            "Content-Type": "application/json"
        }

    })
  }
        }