const button = document.querySelector("button.uc-form-button-submit");

button.addEventListener("click", async (e) => {
  e.preventDefault();

  const GroupBy = document.querySelector("#GroupBy").value;
  const trans_date = document.querySelector("#trans_date").value;
  const SortBy = document.querySelector("#SortBy").value;

  const ranking = new Ranking(GroupBy, trans_date, SortBy);
  ranking.get();

  localStorage.setItem('GroupBy', GroupBy);
  localStorage.setItem('trans_date', trans_date);
  localStorage.setItem('SortBy', SortBy);

  let redirectUrl = "RankingReportTab.html";

  if (SortBy === "Lowest") {
    redirectUrl = "RankingReportLowest.html";
  }

  setTimeout(() => {
    window.location.href = redirectUrl;
  }, 1000);
});
