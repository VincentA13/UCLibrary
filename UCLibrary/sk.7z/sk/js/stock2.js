window.onload = async function() {
  await loadStock()
}

async function loadStock() {
  const response = await fetch("http://localhost:5000/trans_in_out", {
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    }
  })

  if (response.status === 200) {
    const ucTable = document.querySelector("#uc-table-stock")
    const datas = await response.json()

    if (ucTable) {
      let inner = ""
      for (const data of datas) {
        const template = `
          <div class="uc-table-row">
            <span class="uc-table-row-data uc-table-row-data-titemid">${data.trans_item_id}</span>
            <span class="uc-table-row-data uc-table-row-data-tdate">${data.trans_date}</span>
            <span class="uc-table-row-data uc-table-row-data-ttype">${data.transformed_trans_type}</span>
            <span class="uc-table-row-data uc-table-row-data-tqty">${data.trans_qty || 0}</span>
          </div>
        `
        inner += template
      }
      ucTable.innerHTML = inner
    }
  }
}
