window.onload = async function() {
  await loadStock()
}

async function loadStock() {
  const response = await fetch("http://localhost:5000/opnametab", {
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    }
  })

  if (response.status === 200) {
    const ucTable = document.querySelector("#uc-table-stock")
    const datas = await response.json()

    if (ucTable) {
      let inner = ""
      for (const data of datas) {
        const template = `
          <div class="uc-table-row" onclick="clickHandler('${data.item_id}')">
            <span class="uc-table-row-data uc-table-row-data-date">${data.opname_date}</span>
            <span class="uc-table-row-data uc-table-row-data-name">${data.opname_item_id}</span>
            <span class="uc-table-row-data uc-table-row-data-db">${data.opname_db_qty}</span>
            <span class="uc-table-row-data uc-table-row-data-store">${data.opname_store_qty}</span>
            <span class="uc-table-row-data uc-table-row-data-reason">${data.opname_reason}</span>
          </div>
        `
        inner += template
      }
      ucTable.innerHTML = inner
    }
  }
}
