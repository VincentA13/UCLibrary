const button = document.querySelector("button.uc-form-button-submit")
let edit_item = null

button.addEventListener("click", (e) => {
    e.preventDefault()

    const opname_item_id = document.querySelector("#item_id").value
    const item_name = document.querySelector("#item_name").value
    const opname_store_qty = parseInt(document.querySelector("#opname_store_qty").value)
    const opname_reason = document.querySelector("#opname_reason").value
    const opname_db_qty = parseInt(document.querySelector("#item_cur_qty").value)

    if (
        opname_item_id &&
        opname_db_qty >= 0
    ) {
        const opname = new Opname(opname_item_id, opname_db_qty, opname_store_qty, opname_reason)
        opname.save();
                setTimeout(() => {
            window.location.href = "Opname.html";
        }, 1000);
        }
        }

        )

window.onload = async function() {
    const edit_id = localStorage.getItem('item-edit-id')
    if (edit_id) {
        edit_item = await loadItem(edit_id)

        if (edit_item) {
            document.querySelector("#item_id").value = edit_item.item_id || ""
            document.querySelector("#item_name").value = edit_item.item_name || ""
            document.querySelector("#item_cur_qty").value = edit_item.item_cur_qty || "0"
            document.querySelector("#item_cur_qty").setAttribute("readonly", true)
        }

    }
    localStorage.removeItem('item-edit-id')

}



async function loadItem(id) {
    try {
      const response = await fetch(`http://localhost:5000/item/${id}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json"
        }
      })
      if (response.status === 200) {
        return await response.json()
      }
      return null
    } catch {
      return null
    }
  }