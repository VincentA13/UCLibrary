// Extract GroupBy from localStorage
const GroupBy = localStorage.getItem('GroupBy');
const trans_date = localStorage.getItem('trans_date');
const SortBy = localStorage.getItem('SortBy');
if (GroupBy) {
  fetch(`http://localhost:5000/Ranking?GroupBy=${GroupBy}&trans_date=${trans_date}&SortBy=${SortBy}`)
    .then(response => {
      if (response.status === 200) {
        return response.json();
      } else {
        throw new Error("Failed to fetch data");
      }
    })
    .then(uctable => {
      // Populate the tables with the retrieved data
      populateTables(uctable, 'uc-table-stock', GroupBy);
    })
    .catch(error => {
      console.error(SortBy);
    });
} else {
  // Handle the case where GroupBy is not available in localStorage
  console.log("Data is missing from localStorage");
}

function populateTables(uctable, tableId, GroupBy) {
  if (uctable) {
    const ucTable = document.querySelector(`#${tableId}`);
    let innerHTML = "";

    for (const item of uctable) {

      const row = `
        <div class="uc-table-row">
          <span class="uc-table-row-data uc-table-row-data-id">${item.item_id}</span>
          <span class="uc-table-row-data uc-table-row-data-name">${item.item_name}</span>
          <span class="uc-table-row-data uc-table-row-data-qty">${item.item_cur_qty || 0}</span>
        </div>
      `;
      innerHTML += row;
    }


    ucTable.innerHTML = innerHTML;
  }
}
