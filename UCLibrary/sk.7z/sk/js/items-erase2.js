const button = document.querySelector("button.uc-form-button-submit")
let erase_item = null

button.addEventListener("click", (e) => {
    e.preventDefault()

    const item_id = document.querySelector("#item_id").value
    const item_type = document.querySelector("#item_type").value
    const item_name = document.querySelector("#item_name").value
    const item_brand = document.querySelector("#item_brand").value
    const item_cur_qty = parseInt(document.querySelector("#item_cur_qty").value)

        const item = new Item(item_id, item_name, item_type, item_brand, item_cur_qty)
        if (erase_item) {
            item.setId(erase_item.item_id)
            item.erase(item_id, item_name, item_type, item_brand, item_cur_qty)
        }
                setTimeout(() => {
            window.location.href = "Database-Stok-search.html";
        }, 1000);
    }
)

window.onload = async function() {
    const erase_id = localStorage.getItem('item-erase-id')
    if (erase_id) {
        erase_item = await loadItem(erase_id)

        if (erase_item) {
            document.querySelector("#item_id").value = erase_item.item_id || ""
            document.querySelector("#item_type").value = erase_item.item_type || ""
            document.querySelector("#item_name").value = erase_item.item_name || ""
            document.querySelector("#item_brand").value = erase_item.item_brand || ""
            document.querySelector("#item_cur_qty").value = erase_item.item_cur_qty || "0"
            document.querySelector("#item_cur_qty").setAttribute("readonly", true)
        }
    }
    console.log()
    localStorage.removeItem('item-erase-id')
}

async function loadItem(id) {
    try {
      const response = await fetch(`http://localhost:5000/item/${id}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json"
        }
      })
      if (response.status === 200) {
        return await response.json()
      }
      return null
    } catch {
      return null
    }
  }