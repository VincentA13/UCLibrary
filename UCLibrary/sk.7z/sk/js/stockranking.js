// Extract GroupBy from localStorage
const GroupBy = localStorage.getItem('GroupBy');
const trans_date = localStorage.getItem('trans_date');
const SortBy = localStorage.getItem('SortBy');

if (GroupBy) {
  fetch(`http://localhost:5000/Ranking?GroupBy=${GroupBy}&trans_date=${trans_date}&SortBy=${SortBy}`)
    .then(response => {
      if (response.status === 200) {
        return response.json();
      } else {
        throw new Error("Failed to fetch data");
      }
    })
    .then(uctable => {
      // Populate the tables with the retrieved data
      populateTables(uctable, 'uc-table-stock', GroupBy);
    })
    .catch(error => {
      console.error(GroupBy);
    });
} else {
  // Handle the case where GroupBy is not available in localStorage
  console.log("Data is missing from localStorage");
}

function getPropertyBasedOnGroupBy(item, GroupBy) {
  // Convert both GroupBy and the values to lowercase for a case-insensitive comparison
  GroupBy = GroupBy.toLowerCase();

  switch (GroupBy) {
    case 'item_id':
      return item.trans_item_id;
    case 'brand':
      return item.item_brand;
    case 'type':
      return item.item_type;
    default:
      return ''; // Handle invalid GroupBy values
  }
}

function populateTables(uctable, tableId, GroupBy) {
  if (uctable) {
    const ucTable = document.querySelector(`#${tableId}`);
    let innerHTML = "";

    for (const item of uctable) {
      const value = getPropertyBasedOnGroupBy(item, GroupBy);

      const row = `
        <div class="uc-table-row">
          <span class="uc-table-row-data uc-table-row-data-group">${value}</span>
          <span class="uc-table-row-data uc-table-row-data-tqty">${item.total_sales || 0}</span>
        </div>
      `;
      innerHTML += row;
    }

    ucTable.innerHTML = innerHTML;
  }
}
