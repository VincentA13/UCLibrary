class Item {
  constructor(item_name, item_type, item_brand, item_cur_qty) {
    this.item_name = item_name
    this.item_type = item_type
    this.item_brand = item_brand
    this.item_cur_qty = item_cur_qty
  }

  setId(id) {
    this.item_id = id
  }
  async isUnique(id) {
    // CHECK IF ITEM's ID IS UNIQUE
    return true
  }
  async save() {
    // SAVE TO DB
    return await fetch("http://localhost:5000/item", {
        method: "POST",
        body: JSON.stringify(this),
        headers: {
            "Content-Type": "application/json"
        }
    })
  }
  async update(item_name, item_type, item_brand) {
    if (item_name) this.item_name = item_name
    if (item_type) this.item_type = item_type
    if (item_brand) this.item_brand = item_brand
    // UPDATE TO DB
    return await fetch(`http://localhost:5000/item/${this.item_id}`, {
        method: "PUT",
        body: JSON.stringify(this),
        headers: {
            "Content-Type": "application/json"
        }
    })
  }
async erase(item_id) {
    if (item_id) this.item_id = item_id;
    // ERASE DB
    return await fetch(`http://localhost:5000/item/${this.item_id}`, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
        }
    });
}
}

