class Opname {
  constructor(opname_date, opname_item_id, opname_db_qty, opname_store_qty, opname_reason) {
    this.opname_date = opname_date;
    this.opname_item_id = opname_item_id;
    this.opname_db_qty = opname_db_qty;
    this.opname_store_qty = opname_store_qty;
    this.opname_reason = opname_reason;
  }

  setId(id) {
    this.opname_id = id
  }
  async isUnique(id) {
    // CHECK IF ITEM's ID IS UNIQUE
    return true
  }
  async save() {
    if (opname_id) this.opname_id = opname_id
    // SAVE TO DB
    return await fetch("http://localhost:5000/opnametab", {
        method: "POST",
        body: JSON.stringify(this),
        headers: {
            "Content-Type": "application/json"
        }
    })
  }
    }


