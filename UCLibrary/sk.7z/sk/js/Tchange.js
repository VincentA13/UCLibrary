const button = document.querySelector("button.uc-form-button-submit")
let edit_item = null

button.addEventListener("click", (e) => {
    e.preventDefault()

    const trans_item_id = document.querySelector("#trans_item_id").value
    const trans_type = document.querySelector("#trans_type").value
    const trans_qty = parseInt(document.querySelector("#trans_qty").value)

    if (
        trans_item_id &&
        trans_type &&
        trans_qty >= 0
    ) {
        const trans_in_out = new trans_in_out(trans_item_id, trans_type, trans_qty)
        if (edit_trans_in_out) {
            trans_in_out.setId(edit_trans_in_out.trans_id)
            trans_in_out.update(trans_item_id, trans_type, trans_qty)
        } else {
            trans_in_out.save()
        }
    }
})

window.onload = async function() {
    const edit_id = localStorage.getItem('trans_in_out-edit-id')
    if (edit_id) {
        edit_item = await loadItem(edit_id)

        if (edit_item) {
            document.querySelector("#item_type").value = edit_item.item_type || ""
            document.querySelector("#item_name").value = edit_item.item_name || ""
            document.querySelector("#item_brand").value = edit_item.item_brand || ""
            document.querySelector("#item_cur_qty").setAttribute("readonly", true)
        }
    }
    localStorage.removeItem('item-edit-id')
}

async function loadItem(id) {
    try {
      const response = await fetch(`http://localhost:5000/trans_in_out/${id}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        }
      })
      if (response.status === 200) {
        return await response.json()
      }
      return null
    } catch {
      return null
    }
  }