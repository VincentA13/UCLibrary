window.onload = async function() {
  await loadStock()
}

async function loadStock() {
  const response = await fetch("http://localhost:5000/item", {
    method: "GET",
    headers: {
      "Content-Type": "application/json"
    }
  })

  if (response.status === 200) {
    const ucTable = document.querySelector("#uc-table-stock")
    const datas = await response.json()

    if (ucTable) {
      let inner = ""
      for (const data of datas) {
        const template = `
          <div class="uc-table-row" onclick="clickHandler('${data.item_id}')">
            <span class="uc-table-row-data uc-table-row-data-id">${data.item_id}</span>
            <span class="uc-table-row-data uc-table-row-data-name">${data.item_name}</span>
            <span class="uc-table-row-data uc-table-row-data-type">${data.item_type}</span>
            <span class="uc-table-row-data uc-table-row-data-brand">${data.item_brand}</span>
            <span class="uc-table-row-data uc-table-row-data-qty">${data.item_cur_qty || 0}</span>
          </div>
        `
        inner += template
      }
      ucTable.innerHTML = inner
    }
  }
}

function clickHandler(id) {
  localStorage.setItem('item-edit-id', id)
  window.location.href = './change_trans.html'
}